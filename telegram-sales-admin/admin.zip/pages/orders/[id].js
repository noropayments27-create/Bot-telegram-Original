import { useEffect, useState } from "react";
import { useRouter } from "next/router";

import { apiFetch, apiFetchBinary, getAuthToken } from "../../lib/api";

export default function OrderDetail() {
  const router = useRouter();
  const { id } = router.query;
  const [detail, setDetail] = useState(null);
  const [proofUrl, setProofUrl] = useState("");
  const [reason, setReason] = useState("");
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    if (!getAuthToken()) {
      router.replace("/login");
    }
  }, [router]);

  const loadDetail = async () => {
    if (!id) {
      return;
    }
    try {
      const data = await apiFetch(`/admin/orders/${id}`);
      setDetail(data);
      setError("");
      setMessage("");
    } catch (err) {
      setError("No se pudo cargar la orden.");
    }
  };

  useEffect(() => {
    loadDetail();
  }, [id]);

  useEffect(() => {
    const loadProof = async () => {
      if (!id) {
        return;
      }
      try {
        const result = await apiFetchBinary(`/admin/orders/${id}/payment-proof`);
        const blob = new Blob([result.buffer], { type: result.contentType });
        const url = URL.createObjectURL(blob);
        setProofUrl(url);
      } catch (err) {
        setProofUrl("");
      }
    };

    loadProof();
    return () => {
      if (proofUrl) {
        URL.revokeObjectURL(proofUrl);
      }
    };
  }, [id]);

  const handleApprove = async () => {
    try {
      await apiFetch(`/admin/orders/${id}/mark-paid`, { method: "POST" });
      setMessage("Pago aprobado.");
      await loadDetail();
    } catch (err) {
      setError("No se pudo aprobar el pago.");
    }
  };

  const handleReject = async (mode) => {
    try {
      await apiFetch(`/admin/orders/${id}/reject`, {
        method: "POST",
        body: JSON.stringify({ mode, reason: reason || undefined }),
      });
      setMessage("Pago rechazado.");
      await loadDetail();
    } catch (err) {
      setError("No se pudo rechazar el pago.");
    }
  };

  const handleDownload = async () => {
    try {
      const result = await apiFetchBinary(
        `/admin/orders/${id}/payment-proof/download`
      );
      const blob = new Blob([result.buffer], { type: result.contentType });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `order_${id}_payment_proof.jpg`;
      document.body.appendChild(link);
      link.click();
      link.remove();
      URL.revokeObjectURL(url);
    } catch (err) {
      setError("No se pudo descargar la prueba.");
    }
  };

  if (!detail) {
    return (
      <main className="page">
        <section className="card">
          <p>Cargando...</p>
        </section>
      </main>
    );
  }

  const { order, user, product, payment, commission } = detail;
  const hasProof = Boolean(payment && payment.screenshot_file_id);
  const isPaid = order.status === "PAID";

  return (
    <main className="page">
      <section className="card">
        <h1>Orden {order.id}</h1>
        {message && <p className="muted">{message}</p>}
        {error && <p className="error">{error}</p>}

        <h3>Detalle</h3>
        <p>Estado: {order.status}</p>
        <p>Precio: {order.unit_price_at_purchase}</p>
        <p>Creada: {new Date(order.created_at).toLocaleString()}</p>
        {order.paid_at && <p>Pagada: {new Date(order.paid_at).toLocaleString()}</p>}

        <h3>Usuario</h3>
        <p>Telegram ID: {user.telegram_id}</p>
        <p>Username: {user.telegram_username || "-"}</p>

        <h3>Producto</h3>
        <p>ID: {product.id}</p>
        <p>Código: {product.code || "N/A"}</p>
        <p>Nombre: {product.name}</p>
        <p>Precio: {product.price}</p>

        <h3>Pago</h3>
        {payment ? (
          <>
            <p>File ID: {payment.screenshot_file_id}</p>
            <p>Estado revision: {payment.review_status}</p>
            <p>Enviado: {new Date(payment.submitted_at).toLocaleString()}</p>
          </>
        ) : (
          <p>No hay pago registrado.</p>
        )}

        <h3>Comision</h3>
        {commission ? (
          <>
            <p>ID: {commission.id}</p>
            <p>Monto: {commission.amount}</p>
            <p>Estado: {commission.status}</p>
          </>
        ) : (
          <p>No aplica.</p>
        )}

        <h3>Screenshot</h3>
        {hasProof && proofUrl ? (
          <>
            <img src={proofUrl} alt="Proof" style={{ width: "100%" }} />
            <button type="button" onClick={handleDownload}>
              Descargar
            </button>
          </>
        ) : (
          <p>No hay screenshot.</p>
        )}

        <h3>Acciones</h3>
        <div className="form">
          <label>
            Motivo (opcional)
            <input
              type="text"
              value={reason}
              onChange={(event) => setReason(event.target.value)}
              placeholder="Motivo"
            />
          </label>
        </div>
        <div className="actions">
          <button type="button" onClick={handleApprove} disabled={!hasProof || isPaid}>
            Aprobar pago
          </button>
          <button type="button" onClick={() => handleReject("retry")} disabled={!hasProof}>
            Rechazar (retry)
          </button>
          <button type="button" onClick={() => handleReject("cancel")} disabled={!hasProof}>
            Rechazar (cancel)
          </button>
        </div>
      </section>
    </main>
  );
}
